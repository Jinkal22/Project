const mongoose=require('mongoose')

const schema= mongoose.Schema(
    {
        _id: mongoose.Types.ObjectId ,
        CID: Number,
        ClothesName: String,
        ClothesImage: String,
        ClothesPrice: Number,
    }
)
module.exports=mongoose.model("Clothes",schema)