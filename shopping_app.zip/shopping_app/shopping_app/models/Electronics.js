const mongoose=require('mongoose')

const schema= mongoose.Schema(
    {
        _id: Number,
        EID: Number,
        ElementlectronicsName: String,
        ElectronicsImage: String,
        ElectronicsPrice: Number,
    }
)
module.exports=mongoose.model("Electronics",schema)