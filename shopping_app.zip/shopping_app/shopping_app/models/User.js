const mongoose=require('mongoose')

const schema= mongoose.Schema(
    {
        UID: Number,
        username:String,
        password:String
    }
)
module.exports=mongoose.model("User",schema)