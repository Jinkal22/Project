const mongoose=require('mongoose')

const schema= mongoose.Schema(
    {
        _id: mongoose.Types.ObjectId,
        HID: Number,
        HomeShopName: String,
        HomeShopPrice: String,
        HomeShopImage: String,
    }
)
module.exports=mongoose.model("HomeShop",schema)