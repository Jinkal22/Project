const mongoose=require('mongoose')

const schema= mongoose.Schema(
    {
        ID: Number,
        Name: String,
        Price: String,
        Image: String,
    }
)
module.exports=mongoose.model("Cart",schema)