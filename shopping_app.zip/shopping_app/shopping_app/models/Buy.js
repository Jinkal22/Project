const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  username: { type: String , require:true},
  productId: { type: Number },
  productName: { type: String },
  productPrice: { type: String},
  productImage: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Order', orderSchema);
