const mongoose=require('mongoose')

const schema= mongoose.Schema(
    {
        _id: mongoose.Types.ObjectId,
        BID:Number,
        BeautyName: String,
        BeautyPrice: String,
        BeautyImage: String,
    }
)
module.exports=mongoose.model("Beauty",schema)